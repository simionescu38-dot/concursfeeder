@echo off
setlocal
title AutoCut Fishing - Build Windows
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo Ruleaza mai intai setup_windows.bat.
  pause
  exit /b 1
)

if not exist "models\faster-whisper-base\model.bin" (
  echo Se pregateste modelul romanesc de subtitrare pentru utilizare offline...
  ".venv\Scripts\python.exe" -c "from huggingface_hub import snapshot_download; snapshot_download('Systran/faster-whisper-base', local_dir=r'models\faster-whisper-base')"
  if errorlevel 1 (
    echo Modelul de subtitrare nu a putut fi pregatit.
    pause
    exit /b 1
  )
)

set "FFMPEG_PATH="
set "FFPROBE_PATH="
for /f "delims=" %%I in ('where ffmpeg 2^>nul') do if not defined FFMPEG_PATH set "FFMPEG_PATH=%%I"
for /f "delims=" %%I in ('where ffprobe 2^>nul') do if not defined FFPROBE_PATH set "FFPROBE_PATH=%%I"
if not defined FFMPEG_PATH (
  echo FFmpeg nu a fost gasit. Ruleaza setup_windows.bat o singura data pe calculatorul de build.
  pause
  exit /b 1
)
if not defined FFPROBE_PATH (
  echo FFprobe nu a fost gasit.
  pause
  exit /b 1
)

echo Se construieste aplicatia Windows...
".venv\Scripts\python.exe" -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --name "AutoCut Fishing" ^
  --icon "assets\autocut_fishing.ico" ^
  --add-data "assets;assets" ^
  --add-data "apply_update.ps1;." ^
  --add-data "models\faster-whisper-base;models\faster-whisper-base" ^
  --add-binary "%FFMPEG_PATH%;." ^
  --add-binary "%FFPROBE_PATH%;." ^
  --collect-all faster_whisper ^
  --collect-all ctranslate2 ^
  --collect-all tokenizers ^
  --collect-data mediapipe ^
  --hidden-import mediapipe.python.solutions.pose ^
  --hidden-import autocut.tracking ^
  --hidden-import autocut.subtitles ^
  --hidden-import autocut.highlights ^
  app.py

if errorlevel 1 (
  echo Build-ul a esuat. Verifica mesajele de mai sus.
  pause
  exit /b 1
)

echo.
echo Aplicatia a fost creata in:
echo dist\AutoCut Fishing\AutoCut Fishing.exe

where ISCC >nul 2>nul
if not errorlevel 1 (
  echo Se creeaza si kitul de instalare...
  ISCC AutoCutFishing.iss
  echo Kitul este in installer\AutoCut-Fishing-Setup.exe
) else (
  echo.
  echo Optional: instaleaza Inno Setup pentru a crea si un kit Setup.exe.
)
pause
