from __future__ import annotations

import os
import json
import logging
import queue
import subprocess
import sys
import threading
from pathlib import Path
from logging.handlers import RotatingFileHandler
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from autocut.core import (
    ProcessingError,
    ProcessingOptions,
    ProcessingResult,
    bundled_resource,
    create_tracking_preview,
    process_video,
    require_tools,
)


APP_NAME = "AutoCut Fishing"
APP_VERSION = "1.1.1"
BG = "#07181b"
PANEL = "#0d2427"
PANEL_LIGHT = "#133237"
ACCENT = "#31d6a0"
ACCENT_DARK = "#1aa77a"
TEXT = "#eefaf6"
MUTED = "#9bb8b1"
WARNING = "#ffcf66"


def app_data_dir() -> Path:
    if sys.platform.startswith("win"):
        root = Path(os.environ.get("LOCALAPPDATA", Path.home()))
    else:
        root = Path.home() / ".local" / "share"
    path = root / "AutoCut Fishing"
    path.mkdir(parents=True, exist_ok=True)
    return path


LOG_PATH = app_data_dir() / "autocut.log"
PENDING_JOB_PATH = app_data_dir() / "pending_job.json"


def configure_logging() -> None:
    handler = RotatingFileHandler(
        LOG_PATH, maxBytes=1_000_000, backupCount=2, encoding="utf-8"
    )
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logging.getLogger().setLevel(logging.INFO)
    logging.getLogger().addHandler(handler)


def resource_path(relative: str) -> Path:
    root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return root / relative


def open_path(path: Path) -> None:
    if sys.platform.startswith("win"):
        os.startfile(path)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


def self_test() -> int:
    """Non-interactive packaged-build check used before publishing the installer."""
    import cv2
    import mediapipe as mp
    from faster_whisper import WhisperModel  # noqa: F401

    require_tools()
    if not hasattr(mp, "solutions"):
        raise RuntimeError("MediaPipe nu include API-ul de urmărire necesar.")
    if not cv2.__version__:
        raise RuntimeError("OpenCV nu s-a încărcat.")
    model_path = bundled_resource("models", "faster-whisper-base", "model.bin")
    if not model_path.is_file():
        raise RuntimeError("Modelul offline de subtitrare lipsește din pachet.")
    return 0


class AutoCutApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("980x790")
        self.minsize(900, 720)
        self.configure(bg=BG)
        self.input_path = tk.StringVar()
        self.output_dir = tk.StringVar(value=str(Path.home() / "Videos" / "AutoCut Fishing"))
        self.framing = tk.StringVar(value="smart")
        self.subtitles = tk.BooleanVar(value=True)
        self.threshold = tk.DoubleVar(value=-35.0)
        self.minimum_silence = tk.DoubleVar(value=0.8)
        self.padding = tk.DoubleVar(value=0.18)
        self.model = tk.StringVar(value="base")
        self.short_duration = tk.StringVar(value="60 sec")
        self.highlight_selection = tk.BooleanVar(value=True)
        self.number_of_shorts = tk.StringVar(value="1")
        self.platform = tk.StringVar(value="Universal 9:16")
        self.progress_value = tk.DoubleVar(value=0)
        self.status = tk.StringVar(value="Alege o filmare pentru a începe.")
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.last_result: ProcessingResult | None = None
        self.worker: threading.Thread | None = None
        self._configure_style()
        self._set_icon()
        self._build_ui()
        self._restore_pending_job()
        self.after(120, self._poll_events)

    def _set_icon(self) -> None:
        icon = resource_path("assets/autocut_fishing.png")
        if icon.exists():
            try:
                self._icon_image = tk.PhotoImage(file=str(icon))
                self.iconphoto(True, self._icon_image)
            except tk.TclError:
                pass

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background=BG)
        style.configure("Panel.TFrame", background=PANEL)
        style.configure("Card.TFrame", background=PANEL_LIGHT)
        style.configure("TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 10))
        style.configure("Panel.TLabel", background=PANEL, foreground=TEXT)
        style.configure("Muted.TLabel", background=PANEL, foreground=MUTED, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=BG, foreground=TEXT, font=("Segoe UI Semibold", 24))
        style.configure("Subtitle.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 10))
        style.configure("Section.TLabel", background=PANEL, foreground=TEXT, font=("Segoe UI Semibold", 12))
        style.configure("Accent.TButton", background=ACCENT, foreground="#032018", borderwidth=0, padding=(22, 12), font=("Segoe UI Semibold", 11))
        style.map("Accent.TButton", background=[("active", "#5ce5b8"), ("disabled", "#365e55")])
        style.configure("Secondary.TButton", background=PANEL_LIGHT, foreground=TEXT, borderwidth=0, padding=(14, 9), font=("Segoe UI Semibold", 9))
        style.map("Secondary.TButton", background=[("active", "#1b444a")])
        style.configure("TEntry", fieldbackground="#082024", foreground=TEXT, insertcolor=TEXT, bordercolor="#245158", padding=8)
        style.configure("TCombobox", fieldbackground="#082024", background=PANEL_LIGHT, foreground=TEXT, arrowcolor=TEXT, padding=6)
        style.configure("TCheckbutton", background=PANEL, foreground=TEXT, indicatorbackground="#082024", indicatorforeground=ACCENT, font=("Segoe UI", 10))
        style.map("TCheckbutton", background=[("active", PANEL)])
        style.configure("TRadiobutton", background=PANEL, foreground=TEXT, indicatorbackground="#082024", indicatorforeground=ACCENT, font=("Segoe UI", 10))
        style.map("TRadiobutton", background=[("active", PANEL)])
        style.configure("Horizontal.TProgressbar", background=ACCENT, troughcolor="#082024", bordercolor="#082024", lightcolor=ACCENT, darkcolor=ACCENT)

    def _build_ui(self) -> None:
        root = ttk.Frame(self, padding=(32, 24, 32, 28))
        root.pack(fill="both", expand=True)
        header = ttk.Frame(root)
        header.pack(fill="x", pady=(0, 20))
        badge = tk.Canvas(header, width=62, height=62, bg=BG, highlightthickness=0)
        badge.pack(side="left", padx=(0, 16))
        badge.create_oval(2, 2, 60, 60, fill=ACCENT, outline="")
        badge.create_text(31, 30, text="✂", fill="#032018", font=("Segoe UI Symbol", 24, "bold"))
        title_box = ttk.Frame(header)
        title_box.pack(side="left", fill="x", expand=True)
        ttk.Label(title_box, text=APP_NAME, style="Title.TLabel").pack(anchor="w")
        ttk.Label(title_box, text="Din filmare lungă în Short vertical — local, rapid și simplu.", style="Subtitle.TLabel").pack(anchor="w", pady=(2, 0))

        content = ttk.Frame(root, style="Panel.TFrame", padding=22)
        content.pack(fill="both", expand=True)

        ttk.Label(content, text="1  FILMAREA", style="Section.TLabel").grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Entry(content, textvariable=self.input_path).grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 16), padx=(0, 10))
        ttk.Button(content, text="Alege video", style="Secondary.TButton", command=self._choose_video).grid(row=1, column=2, sticky="ew", pady=(8, 16))

        ttk.Label(content, text="Folder export", style="Panel.TLabel").grid(row=2, column=0, sticky="w")
        ttk.Entry(content, textvariable=self.output_dir).grid(row=3, column=0, columnspan=2, sticky="ew", pady=(6, 20), padx=(0, 10))
        ttk.Button(content, text="Alege folder", style="Secondary.TButton", command=self._choose_output).grid(row=3, column=2, sticky="ew", pady=(6, 20))

        separator = ttk.Separator(content, orient="horizontal")
        separator.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(0, 18))
        ttk.Label(content, text="2  FORMAT SHORT", style="Section.TLabel").grid(row=5, column=0, columnspan=3, sticky="w")
        framing_box = ttk.Frame(content, style="Panel.TFrame")
        framing_box.grid(row=6, column=0, columnspan=3, sticky="ew", pady=(10, 18))
        ttk.Radiobutton(
            framing_box,
            text="Urmărire automată — ecran complet",
            variable=self.framing,
            value="smart",
        ).pack(side="left", padx=(0, 24))
        ttk.Radiobutton(
            framing_box,
            text="Crop central — ecran complet",
            variable=self.framing,
            value="crop",
        ).pack(side="left")
        ttk.Label(framing_box, text="Durată:", style="Panel.TLabel").pack(side="left", padx=(22, 6))
        ttk.Combobox(
            framing_box,
            textvariable=self.short_duration,
            state="readonly",
            width=8,
            values=("30 sec", "45 sec", "60 sec"),
        ).pack(side="left")

        delivery_box = ttk.Frame(content, style="Card.TFrame", padding=12)
        delivery_box.grid(row=7, column=0, columnspan=3, sticky="ew", pady=(0, 16))
        ttk.Checkbutton(
            delivery_box,
            text="Alege automat momentele importante",
            variable=self.highlight_selection,
        ).pack(side="left")
        ttk.Label(delivery_box, text="Număr Shorts:", background=PANEL_LIGHT, foreground=MUTED).pack(side="left", padx=(28, 6))
        ttk.Combobox(
            delivery_box,
            textvariable=self.number_of_shorts,
            state="readonly",
            width=4,
            values=("1", "2", "3"),
        ).pack(side="left")
        ttk.Label(delivery_box, text="Presetare:", background=PANEL_LIGHT, foreground=MUTED).pack(side="left", padx=(28, 6))
        ttk.Combobox(
            delivery_box,
            textvariable=self.platform,
            state="readonly",
            width=18,
            values=("Universal 9:16", "YouTube Shorts", "TikTok", "Facebook Reels"),
        ).pack(side="left")

        settings = ttk.Frame(content, style="Panel.TFrame")
        settings.grid(row=8, column=0, columnspan=3, sticky="ew")
        self._number_field(settings, "Prag liniște", self.threshold, "dB", 0)
        self._number_field(settings, "Pauză minimă", self.minimum_silence, "sec", 1)
        self._number_field(settings, "Protecție tăietură", self.padding, "sec", 2)

        subtitle_box = ttk.Frame(content, style="Card.TFrame", padding=14)
        subtitle_box.grid(row=9, column=0, columnspan=3, sticky="ew", pady=(20, 18))
        check = ttk.Checkbutton(subtitle_box, text="Generează și inscripționează subtitrări în română", variable=self.subtitles, command=self._toggle_model)
        check.pack(side="left")
        ttk.Label(subtitle_box, text="Model AI inclus:", background=PANEL_LIGHT, foreground=MUTED).pack(side="left", padx=(30, 6))
        self.model_combo = ttk.Combobox(subtitle_box, textvariable=self.model, state="readonly", width=10, values=("base",))
        self.model_combo.pack(side="left")

        ttk.Progressbar(content, variable=self.progress_value, maximum=100).grid(row=10, column=0, columnspan=3, sticky="ew", pady=(2, 8))
        ttk.Label(content, textvariable=self.status, style="Muted.TLabel").grid(row=11, column=0, columnspan=3, sticky="w")

        actions = ttk.Frame(content, style="Panel.TFrame")
        actions.grid(row=12, column=0, columnspan=3, sticky="ew", pady=(18, 0))
        self.start_button = ttk.Button(actions, text="CREEAZĂ SHORT", style="Accent.TButton", command=self._start)
        self.start_button.pack(side="left")
        self.preview_button = ttk.Button(
            actions,
            text="Previzualizare 9:16",
            style="Secondary.TButton",
            command=self._preview,
        )
        self.preview_button.pack(side="left", padx=(12, 0))
        self.open_button = ttk.Button(actions, text="Deschide rezultatul", style="Secondary.TButton", command=self._open_result, state="disabled")
        self.open_button.pack(side="left", padx=(12, 0))
        ttk.Button(
            actions,
            text="Actualizează aplicația",
            style="Secondary.TButton",
            command=self._choose_update,
        ).pack(side="left", padx=(12, 0))
        ttk.Button(
            actions, text="Jurnal", style="Secondary.TButton", command=self._open_log
        ).pack(side="left", padx=(12, 0))
        ttk.Button(actions, text="Resetează", style="Secondary.TButton", command=self._reset).pack(side="right")

        content.columnconfigure(0, weight=1)
        content.columnconfigure(1, weight=1)
        content.columnconfigure(2, weight=0, minsize=130)
        content.rowconfigure(13, weight=1)

    def _number_field(self, parent: ttk.Frame, label: str, variable: tk.DoubleVar, suffix: str, column: int) -> None:
        box = ttk.Frame(parent, style="Panel.TFrame")
        box.grid(row=0, column=column, sticky="ew", padx=(0 if column == 0 else 8, 8 if column < 2 else 0))
        ttk.Label(box, text=label, style="Panel.TLabel").pack(anchor="w")
        line = ttk.Frame(box, style="Panel.TFrame")
        line.pack(fill="x", pady=(6, 0))
        ttk.Entry(line, textvariable=variable, width=9).pack(side="left", fill="x", expand=True)
        ttk.Label(line, text=suffix, style="Muted.TLabel").pack(side="left", padx=(6, 0))
        parent.columnconfigure(column, weight=1)

    def _choose_video(self) -> None:
        path = filedialog.askopenfilename(
            title="Alege filmarea",
            filetypes=[("Filmări video", "*.mp4 *.mov *.mkv *.avi *.m4v"), ("Toate fișierele", "*.*")],
        )
        if path:
            self.input_path.set(path)
            self.status.set("Filmare selectată. Verifică setările și pornește AutoCut.")

    def _choose_output(self) -> None:
        path = filedialog.askdirectory(title="Alege folderul pentru export")
        if path:
            self.output_dir.set(path)

    def _toggle_model(self) -> None:
        self.model_combo.configure(state="readonly" if self.subtitles.get() else "disabled")

    def _validate(self) -> ProcessingOptions | None:
        path = Path(self.input_path.get().strip())
        if not path.is_file():
            messagebox.showwarning(APP_NAME, "Alege mai întâi o filmare validă.")
            return None
        try:
            threshold = float(self.threshold.get())
            minimum = float(self.minimum_silence.get())
            padding = float(self.padding.get())
        except (ValueError, tk.TclError):
            messagebox.showwarning(APP_NAME, "Valorile pentru AutoCut nu sunt valide.")
            return None
        if not -80 <= threshold <= -5 or not 0.2 <= minimum <= 10 or not 0 <= padding <= 2:
            messagebox.showwarning(APP_NAME, "Folosește: prag -80…-5 dB, pauză 0,2…10 sec și protecție 0…2 sec.")
            return None
        return ProcessingOptions(
            noise_threshold_db=threshold,
            minimum_silence=minimum,
            padding=padding,
            framing=self.framing.get(),
            subtitles=self.subtitles.get(),
            whisper_model=self.model.get(),
            maximum_duration=float(self.short_duration.get().split()[0]),
            highlight_selection=self.highlight_selection.get(),
            number_of_shorts=int(self.number_of_shorts.get()),
            platform=self.platform.get(),
        )

    def _start(self) -> None:
        options = self._validate()
        if not options:
            return
        self.start_button.configure(state="disabled")
        self.preview_button.configure(state="disabled")
        self.open_button.configure(state="disabled")
        self.progress_value.set(0)
        self.last_result = None
        input_path = Path(self.input_path.get())
        output_dir = Path(self.output_dir.get())
        self._save_pending_job()

        def run() -> None:
            try:
                result = process_video(
                    input_path,
                    output_dir,
                    options,
                    progress=lambda p, m: self.events.put(("progress", (p, m))),
                )
                self.events.put(("done", result))
            except Exception as exc:
                logging.exception("Procesarea AutoCut a eșuat")
                self.events.put(("error", exc))

        self.worker = threading.Thread(target=run, daemon=True)
        self.worker.start()

    def _poll_events(self) -> None:
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "progress":
                    percent, message = payload  # type: ignore[misc]
                    self.progress_value.set(percent)
                    self.status.set(message)
                elif kind == "done":
                    PENDING_JOB_PATH.unlink(missing_ok=True)
                    self.last_result = payload  # type: ignore[assignment]
                    result = self.last_result
                    self.start_button.configure(state="normal")
                    self.preview_button.configure(state="normal")
                    self.open_button.configure(state="normal")
                    clip_count = len(result.output_videos) or 1
                    self.status.set(
                        f"Gata: {clip_count} Short" + ("-uri" if clip_count > 1 else "")
                    )
                    messagebox.showinfo(
                        APP_NAME,
                        (f"{clip_count} Short-uri sunt gata.\n\n" if clip_count > 1 else "Short-ul este gata.\n\n")
                        +
                        f"Durată inițială: {result.original_duration:.1f} sec\n"
                        f"Durată finală: {result.final_duration:.1f} sec\n"
                        f"Folder: {result.output_video.parent}",
                    )
                elif kind == "preview_done":
                    preview_path = payload  # type: ignore[assignment]
                    self.start_button.configure(state="normal")
                    self.preview_button.configure(state="normal")
                    self.status.set("Previzualizarea 9:16 este gata.")
                    open_path(preview_path)  # type: ignore[arg-type]
                elif kind == "error":
                    self.start_button.configure(state="normal")
                    self.preview_button.configure(state="normal")
                    self.progress_value.set(0)
                    self.status.set("Procesarea s-a oprit. Verifică mesajul afișat.")
                    error = payload
                    title = "Procesarea nu a reușit"
                    if isinstance(error, ProcessingError):
                        messagebox.showerror(title, f"{error}\n\nDetaliile sunt în jurnalul aplicației.")
                    else:
                        messagebox.showerror(title, f"A apărut o eroare neașteptată:\n{error}\n\nDetaliile sunt în jurnal.")
        except queue.Empty:
            pass
        self.after(120, self._poll_events)

    def _open_result(self) -> None:
        if self.last_result and self.last_result.output_video.exists():
            if len(self.last_result.output_videos) > 1:
                open_path(self.last_result.output_video.parent)
            else:
                open_path(self.last_result.output_video)

    def _preview(self) -> None:
        path = Path(self.input_path.get().strip())
        if not path.is_file():
            messagebox.showwarning(APP_NAME, "Alege mai întâi o filmare validă.")
            return
        self.start_button.configure(state="disabled")
        self.preview_button.configure(state="disabled")
        self.status.set("Creez o previzualizare scurtă cu urmărire automată…")
        output_dir = Path(self.output_dir.get())

        def run_preview() -> None:
            try:
                preview = create_tracking_preview(path, output_dir)
                self.events.put(("preview_done", preview))
            except Exception as exc:
                logging.exception("Previzualizarea AutoCut a eșuat")
                self.events.put(("error", exc))

        self.worker = threading.Thread(target=run_preview, daemon=True)
        self.worker.start()

    def _choose_update(self) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(APP_NAME, "Așteaptă terminarea procesării înainte de actualizare.")
            return
        archive = filedialog.askopenfilename(
            title="Alege pachetul nou AutoCut Fishing",
            filetypes=[("Actualizare AutoCut Fishing", "*.zip")],
        )
        if not archive:
            return
        updater = resource_path("apply_update.ps1")
        if not updater.exists():
            messagebox.showerror(APP_NAME, "Componenta de actualizare lipsește.")
            return
        if not messagebox.askyesno(
            APP_NAME,
            "Aplicația se va închide, va instala actualizarea și va porni din nou. Continuăm?",
        ):
            return
        subprocess.Popen(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(updater),
                "-ZipPath",
                archive,
                "-AppRoot",
                str(
                    Path(sys.executable).resolve().parent
                    if getattr(sys, "frozen", False)
                    else Path(__file__).resolve().parent
                ),
                "-AppProcessId",
                str(os.getpid()),
            ],
            creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
        )
        self.destroy()

    def _open_log(self) -> None:
        if not LOG_PATH.exists():
            LOG_PATH.write_text("Jurnalul AutoCut Fishing este gol.\n", encoding="utf-8")
        open_path(LOG_PATH)

    def _save_pending_job(self) -> None:
        data = {
            "input": self.input_path.get(),
            "output": self.output_dir.get(),
            "duration": self.short_duration.get(),
            "shorts": self.number_of_shorts.get(),
            "platform": self.platform.get(),
            "subtitles": self.subtitles.get(),
        }
        PENDING_JOB_PATH.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

    def _restore_pending_job(self) -> None:
        if not PENDING_JOB_PATH.exists():
            return
        try:
            data = json.loads(PENDING_JOB_PATH.read_text(encoding="utf-8"))
            if Path(str(data.get("input", ""))).is_file():
                self.input_path.set(str(data["input"]))
                self.output_dir.set(str(data.get("output") or self.output_dir.get()))
                self.short_duration.set(str(data.get("duration") or "60 sec"))
                self.number_of_shorts.set(str(data.get("shorts") or "1"))
                self.platform.set(str(data.get("platform") or "Universal 9:16"))
                self.subtitles.set(bool(data.get("subtitles", True)))
                self.status.set("Am recuperat ultima procesare întreruptă. Poți porni din nou.")
        except (OSError, ValueError, KeyError):
            logging.exception("Recuperarea ultimei procesări a eșuat")

    def _reset(self) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(APP_NAME, "Așteaptă terminarea procesării înainte de resetare.")
            return
        self.input_path.set("")
        self.progress_value.set(0)
        self.status.set("Alege o filmare pentru a începe.")
        self.last_result = None
        self.open_button.configure(state="disabled")
        PENDING_JOB_PATH.unlink(missing_ok=True)


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        raise SystemExit(self_test())
    configure_logging()
    AutoCutApp().mainloop()
