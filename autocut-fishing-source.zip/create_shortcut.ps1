$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "AutoCut Fishing.lnk"
$targetPath = Join-Path $projectRoot "start_autocut.bat"
$iconPath = Join-Path $projectRoot "assets\autocut_fishing.ico"

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $targetPath
$shortcut.WorkingDirectory = $projectRoot
$shortcut.IconLocation = "$iconPath,0"
$shortcut.Description = "Transformă filmări lungi în Shorts verticale"
$shortcut.Save()

Write-Host "Scurtătura AutoCut Fishing a fost creată pe Desktop."
