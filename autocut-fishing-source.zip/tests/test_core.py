from __future__ import annotations

import tempfile
import unittest
from dataclasses import dataclass
from pathlib import Path

from autocut.core import (
    build_crop_x_expression,
    build_filter_complex,
    keep_segments,
    intersect_segments,
    limit_segments,
    parse_silencedetect,
    write_srt,
)
from autocut.tracking import simplify_positions, smooth_positions
from autocut.subtitles import (
    Caption,
    SubtitleWord,
    group_words,
    words_from_segments,
    write_caption_srt,
    write_highlight_ass,
)
from autocut.highlights import (
    _metadata_points,
    build_activity_timeline,
    select_highlight_windows,
)


class SilenceTests(unittest.TestCase):
    def test_parse_complete_and_trailing_silence(self) -> None:
        text = """
        [silencedetect] silence_start: 1.5
        [silencedetect] silence_end: 3.25 | silence_duration: 1.75
        [silencedetect] silence_start: 8.0
        """
        self.assertEqual(parse_silencedetect(text, 10.0), [(1.5, 3.25), (8.0, 10.0)])

    def test_keep_segments_with_padding(self) -> None:
        kept = keep_segments(10.0, [(2.0, 4.0), (7.0, 9.0)], padding=0.2)
        self.assertEqual(kept, [(0.0, 2.2), (3.8, 7.2), (8.8, 10.0)])

    def test_keep_entire_video_when_no_silence(self) -> None:
        self.assertEqual(keep_segments(5.0, [], padding=0.2), [(0.0, 5.0)])

    def test_limit_segments_to_short_duration(self) -> None:
        limited = limit_segments([(0.0, 20.0), (30.0, 55.0), (70.0, 90.0)], 45.0)
        self.assertEqual(limited, [(0.0, 20.0), (30.0, 55.0)])

    def test_limit_trims_last_segment(self) -> None:
        limited = limit_segments([(0.0, 20.0), (30.0, 55.0)], 30.0)
        self.assertEqual(limited, [(0.0, 20.0), (30.0, 40.0)])

    def test_intersects_kept_segments_with_highlight_window(self) -> None:
        result = intersect_segments([(0.0, 10.0), (15.0, 30.0)], (8.0, 20.0))
        self.assertEqual(result, [(8.0, 10.0), (15.0, 20.0)])


class HighlightTests(unittest.TestCase):
    def test_parses_ffmpeg_metadata(self) -> None:
        text = "frame:0 pts:0 pts_time:0\nvalue=-40.0\nframe:1 pts:1 pts_time:1\nvalue=-20.0"
        self.assertEqual(_metadata_points(text), [(0.0, -40.0), (1.0, -20.0)])

    def test_activity_combines_audio_and_motion(self) -> None:
        timeline = build_activity_timeline(
            3.0,
            [(0.0, -55.0), (1.0, -18.0), (2.0, -55.0)],
            [(0.0, 0.0), (1.0, 1.0), (2.0, 0.0)],
        )
        self.assertEqual(len(timeline), 3)
        self.assertGreater(timeline[1], 0.0)

    def test_selects_separated_highlight_windows(self) -> None:
        activity = [0.1] * 120
        activity[10:20] = [1.0] * 10
        activity[80:90] = [0.9] * 10
        windows = select_highlight_windows(
            120.0, activity, window_duration=20.0, count=2, minimum_gap=5.0
        )
        self.assertEqual(len(windows), 2)
        self.assertTrue(any(start <= 15 < end for start, end in windows))
        self.assertTrue(any(start <= 85 < end for start, end in windows))


class FilterTests(unittest.TestCase):
    def test_filter_maps_audio_and_video(self) -> None:
        graph, video, audio = build_filter_complex(
            [(0.0, 2.0), (3.0, 5.0)], has_audio=True, framing="crop"
        )
        self.assertIn("concat=n=2:v=1:a=1", graph)
        self.assertIn("crop=1080:1920", graph)
        self.assertEqual(video, "[vout]")
        self.assertEqual(audio, "[acat]")

    def test_filter_without_audio(self) -> None:
        graph, _, audio = build_filter_complex(
            [(0.0, 2.0)], has_audio=False, framing="crop"
        )
        self.assertIn("concat=n=1:v=1:a=0", graph)
        self.assertIn("crop=1080:1920", graph)
        self.assertNotIn("boxblur", graph)
        self.assertIsNone(audio)

    def test_dynamic_crop_expression_tracks_and_clamps(self) -> None:
        expression = build_crop_x_expression(
            [(0.0, 0.2), (2.0, 0.8)], frame_width=1920, crop_width=608
        )
        self.assertIn("if(lt(t,2.000)", expression)
        self.assertIn("0.000", expression)
        self.assertTrue(expression.endswith("1232.000)"))


class TrackingTests(unittest.TestCase):
    def test_tracking_is_smoothed_and_holds_last_position(self) -> None:
        positions = smooth_positions(
            [(0.0, 0.8), (0.2, 0.8), (0.4, None), (1.0, None)],
            alpha=0.5,
            hold_seconds=1.5,
        )
        self.assertAlmostEqual(positions[0][1], 0.65)
        self.assertAlmostEqual(positions[1][1], 0.725)
        self.assertAlmostEqual(positions[-1][1], 0.725)

    def test_lost_subject_returns_toward_centre(self) -> None:
        positions = smooth_positions(
            [(0.0, 0.9), (2.0, None), (3.0, None)],
            alpha=1.0,
            hold_seconds=1.0,
            return_speed=0.1,
        )
        self.assertEqual([round(value, 2) for _, value in positions], [0.9, 0.8, 0.7])

    def test_simplification_keeps_first_and_last(self) -> None:
        simplified = simplify_positions([(0.0, 0.5), (0.1, 0.501), (1.0, 0.7)])
        self.assertEqual(simplified, [(0.0, 0.5), (1.0, 0.7)])


@dataclass
class Segment:
    start: float
    end: float
    text: str


class SubtitleTests(unittest.TestCase):
    def test_write_srt(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "test.srt"
            count = write_srt([Segment(0.0, 1.234, "  Fir   întins!  ")], path)
            content = path.read_text(encoding="utf-8-sig")
            self.assertEqual(count, 1)
            self.assertIn("00:00:00,000 --> 00:00:01,234", content)
            self.assertIn("Fir întins!", content)

    def test_groups_words_into_short_readable_captions(self) -> None:
        words = [
            SubtitleWord(index * 0.3, index * 0.3 + 0.25, text)
            for index, text in enumerate(
                ["Avem", "o", "trăsătură", "foarte", "frumoasă", "la", "method", "feeder."]
            )
        ]
        captions = group_words(words, maximum_words=5)
        self.assertEqual(len(captions), 2)
        self.assertLessEqual(max(len(c.words) for c in captions), 5)

    def test_word_fallback_uses_segment_timing(self) -> None:
        segment = Segment(1.0, 2.0, "Fir întins")
        words = words_from_segments([segment])
        self.assertEqual([word.text for word in words], ["Fir", "întins"])
        self.assertAlmostEqual(words[0].start, 1.0)
        self.assertAlmostEqual(words[-1].end, 2.0)

    def test_writes_editable_srt_and_highlighted_ass(self) -> None:
        caption = Caption(
            [
                SubtitleWord(0.0, 0.4, "Avem"),
                SubtitleWord(0.4, 0.8, "pește"),
                SubtitleWord(0.8, 1.2, "frumos!"),
            ]
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            srt = root / "captions.srt"
            ass = root / "captions.ass"
            self.assertEqual(write_caption_srt([caption], srt), 1)
            self.assertEqual(write_highlight_ass([caption], ass), 3)
            ass_text = ass.read_text(encoding="utf-8-sig")
            self.assertEqual(ass_text.count("Dialogue:"), 3)
            self.assertIn("&H00A6F26D&", ass_text)
            self.assertIn("pește", ass_text)


if __name__ == "__main__":
    unittest.main()
