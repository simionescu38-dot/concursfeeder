#define MyAppName "AutoCut Fishing"
#define MyAppVersion "1.1.0"
#define MyAppPublisher "AutoCut Fishing"
#define MyAppExeName "AutoCut Fishing.exe"

[Setup]
AppId={{A8FB518A-682E-47F8-9F7A-E8307E2E4E0B}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\AutoCut Fishing
DefaultGroupName={#MyAppName}
OutputDir=installer
OutputBaseFilename=AutoCut-Fishing-Setup
SetupIconFile=assets\autocut_fishing.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
CloseApplications=yes
RestartApplications=no

[Files]
Source: "dist\AutoCut Fishing\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Creează o iconiță pe Desktop"; GroupDescription: "Scurtături:"; Flags: checkedonce

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Pornește AutoCut Fishing"; Flags: nowait postinstall skipifsilent
