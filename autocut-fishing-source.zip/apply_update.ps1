param(
    [Parameter(Mandatory = $true)][string]$ZipPath,
    [Parameter(Mandatory = $true)][string]$AppRoot,
    [Parameter(Mandatory = $true)][int]$AppProcessId
)

$ErrorActionPreference = "Stop"
$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ("autocut_update_" + [guid]::NewGuid())

try {
    New-Item -ItemType Directory -Path $tempRoot | Out-Null
    Expand-Archive -LiteralPath $ZipPath -DestinationPath $tempRoot -Force
    $manifestPath = Get-ChildItem -Path $tempRoot -Filter "update_manifest.json" -Recurse | Select-Object -First 1
    if (-not $manifestPath) {
        throw "Pachetul ales nu este o actualizare AutoCut Fishing validă."
    }
    $manifest = Get-Content -LiteralPath $manifestPath.FullName -Raw | ConvertFrom-Json
    $payload = Join-Path $manifestPath.Directory.FullName "payload"
    if (-not (Test-Path $payload)) {
        throw "Pachetul de actualizare este incomplet."
    }

    Wait-Process -Id $AppProcessId -ErrorAction SilentlyContinue
    Copy-Item -Path (Join-Path $payload "*") -Destination $AppRoot -Recurse -Force

    if ($manifest.install_dependencies -eq $true) {
        $python = Join-Path $AppRoot ".venv\Scripts\python.exe"
        & $python -m pip install -r (Join-Path $AppRoot "requirements.txt")
        if ($LASTEXITCODE -ne 0) { throw "Componentele actualizării nu au putut fi instalate." }
    }

    $packagedApp = Join-Path $AppRoot "AutoCut Fishing.exe"
    $sourceLauncher = Join-Path $AppRoot "start_autocut.bat"
    if (Test-Path $packagedApp) {
        Start-Process -FilePath $packagedApp -WorkingDirectory $AppRoot
    } elseif (Test-Path $sourceLauncher) {
        Start-Process -FilePath $sourceLauncher -WorkingDirectory $AppRoot
    } else {
        throw "Aplicația actualizată nu conține un fișier de pornire valid."
    }
} catch {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show($_.Exception.Message, "Actualizare AutoCut Fishing") | Out-Null
} finally {
    Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
}
