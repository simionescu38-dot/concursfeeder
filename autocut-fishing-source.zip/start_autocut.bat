@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Aplicatia nu este instalata. Ruleaza mai intai setup_windows.bat.
  pause
  exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" app.py

