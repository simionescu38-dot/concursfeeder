from __future__ import annotations

import math
import re
import shutil
import subprocess
from pathlib import Path
from typing import Iterable


_PTS_RE = re.compile(r"pts_time:([0-9.]+)")
_VALUE_RE = re.compile(r"=([-+0-9.inf]+)")


def _metadata_points(text: str) -> list[tuple[float, float]]:
    points: list[tuple[float, float]] = []
    pending_time: float | None = None
    for line in text.splitlines():
        time_match = _PTS_RE.search(line)
        if time_match:
            pending_time = float(time_match.group(1))
            continue
        value_match = _VALUE_RE.search(line)
        if pending_time is not None and value_match:
            try:
                value = float(value_match.group(1))
            except ValueError:
                value = -100.0
            if math.isfinite(value):
                points.append((pending_time, value))
            pending_time = None
    return points


def _run(command: list[str]) -> str:
    process = subprocess.run(
        command,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        encoding="utf-8",
        errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if process.returncode != 0:
        raise RuntimeError("Analiza momentelor importante a eșuat.")
    return process.stdout


def analyze_audio(path: Path) -> list[tuple[float, float]]:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return []
    output = _run(
        [
            ffmpeg, "-hide_banner", "-nostats", "-i", str(path),
            "-af",
            "asetnsamples=n=44100:p=0,astats=metadata=1:reset=1,"
            "ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-",
            "-vn", "-f", "null", "-",
        ]
    )
    return _metadata_points(output)


def analyze_motion(path: Path) -> list[tuple[float, float]]:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return []
    output = _run(
        [
            ffmpeg, "-hide_banner", "-nostats", "-i", str(path),
            "-vf",
            "fps=2,scale=160:-1,select='gte(scene,0)',"
            "metadata=print:key=lavfi.scene_score:file=-",
            "-an", "-f", "null", "-",
        ]
    )
    return _metadata_points(output)


def normalize_points(
    points: Iterable[tuple[float, float]], *, low: float | None = None, high: float | None = None
) -> list[tuple[float, float]]:
    items = list(points)
    if not items:
        return []
    values = sorted(value for _, value in items)
    lower = low if low is not None else values[max(0, int(len(values) * 0.1) - 1)]
    upper = high if high is not None else values[min(len(values) - 1, int(len(values) * 0.9))]
    span = max(1e-6, upper - lower)
    return [(time, max(0.0, min(1.0, (value - lower) / span))) for time, value in items]


def build_activity_timeline(
    duration: float,
    audio_points: Iterable[tuple[float, float]],
    motion_points: Iterable[tuple[float, float]],
) -> list[float]:
    seconds = max(1, math.ceil(duration))
    audio = normalize_points(audio_points, low=-55.0, high=-18.0)
    motion = normalize_points(motion_points)
    buckets: list[float] = []
    for second in range(seconds):
        audio_values = [value for time, value in audio if second <= time < second + 1]
        motion_values = [value for time, value in motion if second <= time < second + 1]
        audio_score = sum(audio_values) / len(audio_values) if audio_values else 0.0
        motion_score = sum(motion_values) / len(motion_values) if motion_values else 0.0
        buckets.append(audio_score * 0.58 + motion_score * 0.42)

    smoothed: list[float] = []
    for index in range(len(buckets)):
        neighbourhood = buckets[max(0, index - 2) : min(len(buckets), index + 3)]
        smoothed.append(sum(neighbourhood) / len(neighbourhood))
    return smoothed


def select_highlight_windows(
    duration: float,
    activity: list[float],
    *,
    window_duration: float,
    count: int,
    minimum_gap: float = 5.0,
) -> list[tuple[float, float]]:
    if duration <= window_duration:
        return [(0.0, duration)]
    window = max(5, min(math.ceil(window_duration), len(activity)))
    candidates: list[tuple[float, int]] = []
    prefix = [0.0]
    for value in activity:
        prefix.append(prefix[-1] + value)
    for start in range(0, max(1, len(activity) - window + 1)):
        score = (prefix[start + window] - prefix[start]) / window
        candidates.append((score, start))

    selected: list[tuple[float, float]] = []
    for _, start in sorted(candidates, reverse=True):
        end = min(duration, start + window_duration)
        if all(end + minimum_gap <= old_start or start >= old_end + minimum_gap for old_start, old_end in selected):
            selected.append((float(start), float(end)))
            if len(selected) >= max(1, count):
                break
    if not selected:
        selected = [(0.0, min(duration, window_duration))]
    return sorted(selected)


def analyze_and_select(
    path: Path,
    *,
    duration: float,
    has_audio: bool,
    window_duration: float,
    count: int,
) -> list[tuple[float, float]]:
    audio = analyze_audio(path) if has_audio else []
    motion = analyze_motion(path)
    activity = build_activity_timeline(duration, audio, motion)
    return select_highlight_windows(
        duration,
        activity,
        window_duration=window_duration,
        count=count,
        minimum_gap=min(2.0, max(0.5, window_duration * 0.05)),
    )
