from __future__ import annotations

import json
import math
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable, Sequence


ProgressCallback = Callable[[int, str], None]


@dataclass(slots=True)
class VideoInfo:
    duration: float
    width: int
    height: int
    has_audio: bool


@dataclass(slots=True)
class ProcessingOptions:
    noise_threshold_db: float = -35.0
    minimum_silence: float = 0.8
    padding: float = 0.18
    framing: str = "smart"
    subtitles: bool = True
    whisper_model: str = "small"
    language: str = "ro"
    video_quality: int = 20
    maximum_duration: float = 60.0
    highlight_selection: bool = True
    number_of_shorts: int = 1
    platform: str = "Universal"


@dataclass(slots=True)
class ProcessingResult:
    output_video: Path
    subtitle_file: Path | None
    original_duration: float
    final_duration: float
    removed_duration: float
    output_videos: list[Path] = field(default_factory=list)


class ProcessingError(RuntimeError):
    pass


def resource_root() -> Path:
    """Return the PyInstaller bundle root, or the project root in source mode."""
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))


def bundled_resource(*parts: str) -> Path:
    return resource_root().joinpath(*parts)


def require_tools() -> tuple[str, str]:
    executable_suffix = ".exe" if sys.platform.startswith("win") else ""
    bundled_ffmpeg = bundled_resource(f"ffmpeg{executable_suffix}")
    bundled_ffprobe = bundled_resource(f"ffprobe{executable_suffix}")
    ffmpeg = str(bundled_ffmpeg) if bundled_ffmpeg.is_file() else shutil.which("ffmpeg")
    ffprobe = str(bundled_ffprobe) if bundled_ffprobe.is_file() else shutil.which("ffprobe")
    if not ffmpeg or not ffprobe:
        raise ProcessingError(
            "FFmpeg nu este instalat sau nu este disponibil în PATH. "
            "Rulează setup_windows.bat pentru instalare."
        )
    return ffmpeg, ffprobe


def _run(command: Sequence[str], *, description: str) -> subprocess.CompletedProcess[str]:
    process = subprocess.run(
        list(command),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if process.returncode != 0:
        details = process.stderr.strip().splitlines()
        tail = "\n".join(details[-12:])
        raise ProcessingError(f"{description} a eșuat.\n{tail}")
    return process


def probe_video(path: Path) -> VideoInfo:
    _, ffprobe = require_tools()
    result = _run(
        [
            ffprobe,
            "-v",
            "error",
            "-show_entries",
            "format=duration:stream=codec_type,width,height",
            "-of",
            "json",
            str(path),
        ],
        description="Analiza filmării",
    )
    data = json.loads(result.stdout)
    streams = data.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), None)
    if not video:
        raise ProcessingError("Fișierul selectat nu conține o pistă video.")
    duration = float(data.get("format", {}).get("duration") or 0)
    if duration <= 0:
        raise ProcessingError("Durata filmării nu a putut fi determinată.")
    return VideoInfo(
        duration=duration,
        width=int(video.get("width") or 0),
        height=int(video.get("height") or 0),
        has_audio=any(s.get("codec_type") == "audio" for s in streams),
    )


_SILENCE_START_RE = re.compile(r"silence_start:\s*([0-9.]+)")
_SILENCE_END_RE = re.compile(r"silence_end:\s*([0-9.]+)")


def parse_silencedetect(text: str, duration: float) -> list[tuple[float, float]]:
    silences: list[tuple[float, float]] = []
    pending_start: float | None = None
    for line in text.splitlines():
        start_match = _SILENCE_START_RE.search(line)
        if start_match:
            pending_start = max(0.0, float(start_match.group(1)))
        end_match = _SILENCE_END_RE.search(line)
        if end_match:
            end = min(duration, float(end_match.group(1)))
            start = pending_start if pending_start is not None else 0.0
            if end > start:
                silences.append((start, end))
            pending_start = None
    if pending_start is not None and duration > pending_start:
        silences.append((pending_start, duration))
    return silences


def detect_silences(
    path: Path, *, threshold_db: float, minimum_silence: float, duration: float
) -> list[tuple[float, float]]:
    ffmpeg, _ = require_tools()
    process = subprocess.run(
        [
            ffmpeg,
            "-hide_banner",
            "-nostats",
            "-i",
            str(path),
            "-af",
            f"silencedetect=noise={threshold_db:g}dB:d={minimum_silence:g}",
            "-f",
            "null",
            "-",
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if process.returncode != 0:
        raise ProcessingError("Detectarea pauzelor audio a eșuat.")
    return parse_silencedetect(process.stderr, duration)


def keep_segments(
    duration: float,
    silences: Iterable[tuple[float, float]],
    *,
    padding: float,
    minimum_keep: float = 0.25,
) -> list[tuple[float, float]]:
    normalized: list[tuple[float, float]] = []
    for raw_start, raw_end in sorted(silences):
        start = max(0.0, min(duration, raw_start + padding))
        end = max(0.0, min(duration, raw_end - padding))
        if end <= start:
            continue
        if normalized and start <= normalized[-1][1]:
            normalized[-1] = (normalized[-1][0], max(normalized[-1][1], end))
        else:
            normalized.append((start, end))

    kept: list[tuple[float, float]] = []
    cursor = 0.0
    for start, end in normalized:
        if start - cursor >= minimum_keep:
            kept.append((cursor, start))
        cursor = max(cursor, end)
    if duration - cursor >= minimum_keep:
        kept.append((cursor, duration))
    return kept or [(0.0, duration)]


def limit_segments(
    segments: Iterable[tuple[float, float]], maximum_duration: float
) -> list[tuple[float, float]]:
    if maximum_duration <= 0:
        return list(segments)
    limited: list[tuple[float, float]] = []
    remaining = maximum_duration
    for start, end in segments:
        segment_duration = max(0.0, end - start)
        if segment_duration <= 0:
            continue
        take = min(segment_duration, remaining)
        limited.append((start, start + take))
        remaining -= take
        if remaining <= 0.001:
            break
    return limited


def intersect_segments(
    segments: Iterable[tuple[float, float]], window: tuple[float, float]
) -> list[tuple[float, float]]:
    window_start, window_end = window
    result = []
    for start, end in segments:
        clipped_start = max(start, window_start)
        clipped_end = min(end, window_end)
        if clipped_end - clipped_start >= 0.25:
            result.append((clipped_start, clipped_end))
    return result


def _vertical_filter(framing: str) -> str:
    # Every framing mode fills the entire 9:16 canvas. Smart framing uses the
    # dynamic crop path; this is the fixed-centre fallback.
    return (
        "scale=1080:1920:force_original_aspect_ratio=increase,"
        "crop=1080:1920,setsar=1"
    )


def build_filter_complex(
    segments: Sequence[tuple[float, float]], *, has_audio: bool, framing: str
) -> tuple[str, str, str | None]:
    parts: list[str] = []
    concat_inputs: list[str] = []
    for index, (start, end) in enumerate(segments):
        parts.append(
            f"[0:v]trim=start={start:.3f}:end={end:.3f},setpts=PTS-STARTPTS[v{index}]"
        )
        concat_inputs.append(f"[v{index}]")
        if has_audio:
            parts.append(
                f"[0:a]atrim=start={start:.3f}:end={end:.3f},asetpts=PTS-STARTPTS[a{index}]"
            )
            concat_inputs.append(f"[a{index}]")
    if has_audio:
        parts.append(
            "".join(concat_inputs)
            + f"concat=n={len(segments)}:v=1:a=1[vcat][acat]"
        )
        audio_label = "[acat]"
    else:
        parts.append(
            "".join(concat_inputs)
            + f"concat=n={len(segments)}:v=1:a=0[vcat]"
        )
        audio_label = None
    parts.append(f"[vcat]{_vertical_filter(framing)}[vout]")
    return ";".join(parts), "[vout]", audio_label


def build_concat_filter_complex(
    segments: Sequence[tuple[float, float]], *, has_audio: bool
) -> tuple[str, str, str | None]:
    graph, _, audio_label = build_filter_complex(
        segments, has_audio=has_audio, framing="crop"
    )
    graph = graph.rsplit(";[vcat]", 1)[0]
    return graph, "[vcat]", audio_label


def build_crop_x_expression(
    positions: Sequence[tuple[float, float]], *, frame_width: int, crop_width: int
) -> str:
    maximum_x = max(0, frame_width - crop_width)
    if maximum_x == 0 or not positions:
        return "0"
    points = [
        (max(0.0, time), max(0.0, min(float(maximum_x), centre * frame_width - crop_width / 2)))
        for time, centre in positions
    ]
    expression = f"{points[-1][1]:.3f}"
    for index in range(len(points) - 2, -1, -1):
        t0, x0 = points[index]
        t1, x1 = points[index + 1]
        duration = max(0.001, t1 - t0)
        linear = f"{x0:.3f}+({x1 - x0:.3f})*(t-{t0:.3f})/{duration:.3f}"
        expression = f"if(lt(t,{t1:.3f}),{linear},{expression})"
    return expression


def render_source_cut(
    input_path: Path,
    output_path: Path,
    segments: Sequence[tuple[float, float]],
    *,
    has_audio: bool,
    quality: int,
) -> None:
    ffmpeg, _ = require_tools()
    graph, video_label, audio_label = build_concat_filter_complex(segments, has_audio=has_audio)
    script_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ffscript", encoding="utf-8", delete=False) as script:
            script.write(graph)
            script_path = Path(script.name)
        command = [ffmpeg, "-y", "-hide_banner", "-i", str(input_path), "-filter_complex_script", str(script_path), "-map", video_label]
        if audio_label:
            command += ["-map", audio_label]
        command += ["-c:v", "libx264", "-preset", "medium", "-crf", str(max(16, quality - 2)), "-pix_fmt", "yuv420p"]
        if audio_label:
            command += ["-c:a", "aac", "-b:a", "192k"]
        command += ["-movflags", "+faststart", str(output_path)]
        _run(command, description="Eliminarea pauzelor")
    finally:
        if script_path:
            script_path.unlink(missing_ok=True)


def render_smart_vertical(
    input_path: Path,
    output_path: Path,
    positions: Sequence[tuple[float, float]],
    *,
    info: VideoInfo,
    quality: int,
) -> None:
    ffmpeg, _ = require_tools()
    if info.width / max(1, info.height) >= 9 / 16:
        crop_height = info.height - (info.height % 2)
        crop_width = int(crop_height * 9 / 16) // 2 * 2
        x_expression = build_crop_x_expression(
            positions, frame_width=info.width, crop_width=crop_width
        )
        crop = f"crop={crop_width}:{crop_height}:x='{x_expression}':y=0"
    else:
        crop_width = info.width - (info.width % 2)
        crop_height = int(crop_width * 16 / 9) // 2 * 2
        crop = f"crop={crop_width}:{crop_height}:x=0:y=(ih-oh)/2"
    video_filter = f"{crop},scale=1080:1920,setsar=1"
    command = [
        ffmpeg, "-y", "-hide_banner", "-i", str(input_path), "-vf", video_filter,
        "-c:v", "libx264", "-preset", "medium", "-crf", str(quality),
        "-pix_fmt", "yuv420p", "-c:a", "copy", "-movflags", "+faststart", str(output_path),
    ]
    _run(command, description="Încadrarea automată a pescarului")


def create_tracking_preview(input_path: Path, output_dir: Path) -> Path:
    input_path = input_path.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    info = probe_video(input_path)
    preview_duration = min(8.0, info.duration)
    preview_start = max(0.0, min(info.duration - preview_duration, info.duration * 0.25))
    base = re.sub(r"[^\w.-]+", "_", input_path.stem, flags=re.UNICODE).strip("_.")
    output_path = output_dir / f"{base}_PREVIZUALIZARE.mp4"
    counter = 2
    while output_path.exists():
        output_path = output_dir / f"{base}_PREVIZUALIZARE_{counter}.mp4"
        counter += 1

    with tempfile.TemporaryDirectory(
        prefix="autocut_preview_", ignore_cleanup_errors=True
    ) as temp_dir:
        source_cut = Path(temp_dir) / "preview_source.mp4"
        render_source_cut(
            input_path,
            source_cut,
            [(preview_start, preview_start + preview_duration)],
            has_audio=info.has_audio,
            quality=24,
        )
        source_info = probe_video(source_cut)
        try:
            from autocut.tracking import detect_person_positions

            positions = detect_person_positions(source_cut)
            render_smart_vertical(
                source_cut, output_path, positions, info=source_info, quality=24
            )
        except RuntimeError:
            render_vertical_cut(
                source_cut,
                output_path,
                [(0.0, source_info.duration)],
                has_audio=source_info.has_audio,
                framing="crop",
                quality=24,
            )
    return output_path


def render_vertical_cut(
    input_path: Path,
    output_path: Path,
    segments: Sequence[tuple[float, float]],
    *,
    has_audio: bool,
    framing: str,
    quality: int,
) -> None:
    ffmpeg, _ = require_tools()
    filter_complex, video_label, audio_label = build_filter_complex(
        segments, has_audio=has_audio, framing=framing
    )
    script_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".ffscript", encoding="utf-8", delete=False
        ) as script:
            script.write(filter_complex)
            script_path = Path(script.name)
        command = [
            ffmpeg,
            "-y",
            "-hide_banner",
            "-i",
            str(input_path),
            "-filter_complex_script",
            str(script_path),
            "-map",
            video_label,
        ]
        if audio_label:
            command += ["-map", audio_label]
        command += [
            "-c:v",
            "libx264",
            "-preset",
            "medium",
            "-crf",
            str(quality),
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
        ]
        if audio_label:
            command += ["-c:a", "aac", "-b:a", "192k"]
        command.append(str(output_path))
        _run(command, description="Procesarea AutoCut și 9:16")
    finally:
        if script_path:
            script_path.unlink(missing_ok=True)


def _srt_time(seconds: float) -> str:
    total_ms = max(0, round(seconds * 1000))
    hours, remainder = divmod(total_ms, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    secs, millis = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def write_srt(segments: Iterable[object], path: Path) -> int:
    blocks: list[str] = []
    for index, segment in enumerate(segments, start=1):
        start = float(getattr(segment, "start"))
        end = float(getattr(segment, "end"))
        text = " ".join(str(getattr(segment, "text")).strip().split())
        if not text:
            continue
        blocks.append(
            f"{index}\n{_srt_time(start)} --> {_srt_time(end)}\n{text}\n"
        )
    path.write_text("\n".join(blocks), encoding="utf-8-sig")
    return len(blocks)


def transcribe_to_srt(
    video_path: Path,
    subtitle_path: Path,
    *,
    model_name: str,
    language: str,
    styled_path: Path | None = None,
) -> int:
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise ProcessingError(
            "Componenta pentru subtitrări nu este instalată. "
            "Rulează setup_windows.bat."
        ) from exc

    from autocut.subtitles import (
        group_words,
        words_from_segments,
        write_caption_srt,
        write_highlight_ass,
    )

    bundled_model = bundled_resource("models", "faster-whisper-small")
    model_source = str(bundled_model) if bundled_model.is_dir() else model_name
    model = WhisperModel(model_source, device="cpu", compute_type="int8")
    common_options = {
        "language": language,
        "beam_size": 5,
        "word_timestamps": True,
        "hotwords": (
            "feeder method wafter minciog drill vad nadă nădire momitor coșuleț "
            "lansetă mulinetă forfac cârlig trăsătură captură crap caras ten "
            "plătică manșă sector stand juvelnic peleți Remus Lake Rediu Galian Iași"
        ),
        "initial_prompt": (
            "Conversație în limba română între pescari despre feeder și method feeder. "
            "Pot vorbi două sau mai multe persoane. Păstrează termenii de pescuit și "
            "numele locațiilor corect."
        ),
        "condition_on_previous_text": False,
    }

    # The fast VAD pass removes silence efficiently, but on outdoor recordings it
    # can mistake quiet speech for wind/water noise and return no captions. Retry
    # automatically without VAD instead of silently exporting a video with no text.
    segments, _ = model.transcribe(
        str(video_path),
        vad_filter=True,
        vad_parameters={"min_silence_duration_ms": 500, "speech_pad_ms": 400},
        hallucination_silence_threshold=1.2,
        **common_options,
    )
    captions = group_words(words_from_segments(segments))
    if not captions:
        segments, _ = model.transcribe(
            str(video_path),
            vad_filter=False,
            **common_options,
        )
        captions = group_words(words_from_segments(segments))

    if not captions:
        raise ProcessingError(
            "Nu am detectat cuvinte rostite în fragmentul ales. "
            "Verifică dacă vocea se aude și încearcă un fragment care conține dialog."
        )

    count = write_caption_srt(captions, subtitle_path)
    if styled_path is not None and count:
        write_highlight_ass(captions, styled_path)
    return count


def _escape_subtitle_path(path: Path) -> str:
    value = path.resolve().as_posix()
    value = value.replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
    return value


def burn_subtitles(input_path: Path, subtitle_path: Path, output_path: Path, quality: int) -> None:
    ffmpeg, _ = require_tools()
    if subtitle_path.suffix.lower() == ".ass":
        subtitle_filter = f"ass='{_escape_subtitle_path(subtitle_path)}'"
    else:
        style = (
            "FontName=Segoe UI Semibold,FontSize=18,PrimaryColour=&H00FFFFFF,"
            "OutlineColour=&H00111111,BorderStyle=1,Outline=3,Shadow=1,"
            "Alignment=2,MarginV=140"
        )
        subtitle_filter = (
            f"subtitles='{_escape_subtitle_path(subtitle_path)}':force_style='{style}'"
        )
    _run(
        [
            ffmpeg,
            "-y",
            "-hide_banner",
            "-i",
            str(input_path),
            "-vf",
            subtitle_filter,
            "-c:v",
            "libx264",
            "-preset",
            "medium",
            "-crf",
            str(quality),
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "copy",
            "-movflags",
            "+faststart",
            str(output_path),
        ],
        description="Inscripționarea subtitrărilor",
    )


def _safe_output_path(
    input_path: Path,
    output_dir: Path,
    *,
    clip_index: int = 1,
    total_clips: int = 1,
    platform: str = "Universal",
) -> Path:
    base = re.sub(r"[^\w.-]+", "_", input_path.stem, flags=re.UNICODE).strip("_.")
    platform_suffix = {
        "YouTube Shorts": "_YOUTUBE_SHORT",
        "TikTok": "_TIKTOK",
        "Facebook Reels": "_FACEBOOK_REEL",
    }.get(platform, "_SHORT")
    suffix = f"{platform_suffix}_{clip_index:02d}" if total_clips > 1 else platform_suffix
    candidate = output_dir / f"{base}{suffix}.mp4"
    counter = 2
    while candidate.exists():
        candidate = output_dir / f"{base}{suffix}_{counter}.mp4"
        counter += 1
    return candidate


def process_video(
    input_path: Path,
    output_dir: Path,
    options: ProcessingOptions,
    progress: ProgressCallback | None = None,
) -> ProcessingResult:
    notify = progress or (lambda _percent, _message: None)
    input_path = input_path.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    if not input_path.is_file():
        raise ProcessingError("Filmarea selectată nu mai există.")
    output_dir.mkdir(parents=True, exist_ok=True)

    notify(5, "Analizez filmarea…")
    info = probe_video(input_path)
    if info.has_audio:
        notify(15, "Detectez pauzele…")
        silences = detect_silences(
            input_path,
            threshold_db=options.noise_threshold_db,
            minimum_silence=options.minimum_silence,
            duration=info.duration,
        )
        segments = keep_segments(info.duration, silences, padding=options.padding)
    else:
        notify(15, "Filmarea nu are sunet; păstrez întreaga durată…")
        segments = [(0.0, info.duration)]

    kept_segments = segments
    kept_duration = sum(end - start for start, end in kept_segments)
    if kept_duration <= 0.1 or not math.isfinite(kept_duration):
        raise ProcessingError("Nu au rămas secțiuni video valide după analiză.")

    requested_count = max(1, min(3, int(options.number_of_shorts)))
    if options.highlight_selection and info.duration > options.maximum_duration:
        notify(22, "Caut momentele cele mai interesante…")
        try:
            from autocut.highlights import analyze_and_select

            windows = analyze_and_select(
                input_path,
                duration=info.duration,
                has_audio=info.has_audio,
                window_duration=options.maximum_duration,
                count=requested_count,
            )
        except RuntimeError:
            windows = []
    else:
        windows = []

    if not windows:
        windows = []
        cursor = 0.0
        for _ in range(requested_count):
            if cursor >= info.duration:
                break
            windows.append((cursor, min(info.duration, cursor + options.maximum_duration)))
            cursor += options.maximum_duration

    output_videos: list[Path] = []
    subtitle_paths: list[Path] = []
    total_clips = len(windows)
    for clip_number, window in enumerate(windows, start=1):
        segments = limit_segments(
            intersect_segments(kept_segments, window), options.maximum_duration
        )
        if not segments:
            segments = [window]
        output_path = _safe_output_path(
            input_path,
            output_dir,
            clip_index=clip_number,
            total_clips=total_clips,
            platform=options.platform,
        )
        subtitle_path: Path | None = None
        base_progress = 25 + int((clip_number - 1) * 70 / total_clips)
        clip_span = max(1, int(70 / total_clips))

        # Windows video backends may release a temporary MP4 a fraction later
        # than process completion. Cleanup must not invalidate a valid export.
        with tempfile.TemporaryDirectory(
            prefix="autocut_fishing_", ignore_cleanup_errors=True
        ) as temp_dir:
            temp_video = Path(temp_dir) / "vertical_cut.mp4"
            if options.framing == "smart":
                source_cut = Path(temp_dir) / "source_cut.mp4"
                notify(base_progress, f"Short {clip_number}/{total_clips}: elimin pauzele…")
                render_source_cut(
                    input_path, source_cut, segments, has_audio=info.has_audio,
                    quality=options.video_quality,
                )
                notify(base_progress + int(clip_span * 0.22), f"Short {clip_number}/{total_clips}: urmăresc pescarul…")
                try:
                    from autocut.tracking import detect_person_positions

                    positions = detect_person_positions(source_cut)
                except RuntimeError as exc:
                    raise ProcessingError(str(exc)) from exc
                source_info = probe_video(source_cut)
                render_smart_vertical(
                    source_cut, temp_video, positions, info=source_info,
                    quality=options.video_quality,
                )
            else:
                notify(base_progress, f"Short {clip_number}/{total_clips}: creez formatul 9:16…")
                render_vertical_cut(
                    input_path, temp_video, segments, has_audio=info.has_audio,
                    framing=options.framing, quality=options.video_quality,
                )

            if options.subtitles and info.has_audio:
                subtitle_path = output_path.with_suffix(".srt")
                styled_subtitles = Path(temp_dir) / "subtitles.ass"
                notify(base_progress + int(clip_span * 0.55), f"Short {clip_number}/{total_clips}: generez subtitrările…")
                subtitle_count = transcribe_to_srt(
                    temp_video, subtitle_path, model_name=options.whisper_model,
                    language=options.language, styled_path=styled_subtitles,
                )
                if subtitle_count:
                    notify(base_progress + int(clip_span * 0.82), f"Short {clip_number}/{total_clips}: inscripționez subtitrările…")
                    burn_subtitles(
                        temp_video, styled_subtitles, output_path, options.video_quality
                    )
                else:
                    subtitle_path.unlink(missing_ok=True)
                    subtitle_path = None
                    shutil.copy2(temp_video, output_path)
            else:
                shutil.copy2(temp_video, output_path)

        output_videos.append(output_path)
        if subtitle_path:
            subtitle_paths.append(subtitle_path)

    notify(100, f"{len(output_videos)} clipuri gata." if len(output_videos) > 1 else "Clipul este gata.")
    final_info = probe_video(output_videos[0])
    return ProcessingResult(
        output_video=output_videos[0],
        subtitle_file=subtitle_paths[0] if subtitle_paths else None,
        original_duration=info.duration,
        final_duration=final_info.duration,
        removed_duration=max(0.0, info.duration - final_info.duration),
        output_videos=output_videos,
    )
