from __future__ import annotations

import re
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


FISHING_VOCABULARY = (
    "feeder, method feeder, method, wafter, wafters, minciog, drill, vad, nadă, "
    "nădire, momitor, coșuleț, lansetă, mulinetă, forfac, cârlig, trăsătură, "
    "captură, crap, caras, ten, plătică, manșă, sector, stand, juvelnic, peleți, "
    "Remus Lake, Rediu Galian, Iași"
)


@dataclass(slots=True)
class SubtitleWord:
    start: float
    end: float
    text: str
    probability: float = 1.0


@dataclass(slots=True)
class Caption:
    words: list[SubtitleWord]

    @property
    def start(self) -> float:
        return self.words[0].start

    @property
    def end(self) -> float:
        return self.words[-1].end

    @property
    def text(self) -> str:
        return join_words(word.text for word in self.words)


def join_words(words: Iterable[str]) -> str:
    text = " ".join(word.strip() for word in words if word.strip())
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    return re.sub(r"\s+", " ", text).strip()


def words_from_segments(segments: Iterable[object]) -> list[SubtitleWord]:
    result: list[SubtitleWord] = []
    for segment in segments:
        segment_words = list(getattr(segment, "words", None) or [])
        if segment_words:
            for word in segment_words:
                text = str(getattr(word, "word", "")).strip()
                start = float(getattr(word, "start", getattr(segment, "start", 0.0)))
                end = float(getattr(word, "end", start + 0.2))
                probability = float(getattr(word, "probability", 1.0) or 0.0)
                if text and end > start and probability >= 0.12:
                    result.append(SubtitleWord(start, end, text, probability))
            continue

        text_words = str(getattr(segment, "text", "")).strip().split()
        if not text_words:
            continue
        start = float(getattr(segment, "start", 0.0))
        end = max(start + 0.2, float(getattr(segment, "end", start + 0.2)))
        duration = (end - start) / len(text_words)
        for index, text in enumerate(text_words):
            result.append(
                SubtitleWord(start + index * duration, start + (index + 1) * duration, text)
            )
    return result


def group_words(
    words: list[SubtitleWord],
    *,
    maximum_words: int = 7,
    maximum_characters: int = 38,
    maximum_duration: float = 3.2,
    maximum_gap: float = 0.65,
) -> list[Caption]:
    captions: list[Caption] = []
    current: list[SubtitleWord] = []
    for word in words:
        candidate = current + [word]
        should_split = bool(current) and (
            len(candidate) > maximum_words
            or len(join_words(item.text for item in candidate)) > maximum_characters
            or word.end - current[0].start > maximum_duration
            or word.start - current[-1].end > maximum_gap
        )
        if should_split:
            captions.append(Caption(current))
            current = [word]
        else:
            current = candidate

        if current and re.search(r"[.!?…]$", current[-1].text) and len(current) >= 3:
            captions.append(Caption(current))
            current = []
    if current:
        captions.append(Caption(current))
    return captions


def _srt_time(seconds: float) -> str:
    total_ms = max(0, round(seconds * 1000))
    hours, remainder = divmod(total_ms, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    secs, millis = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def _ass_time(seconds: float) -> str:
    total_cs = max(0, round(seconds * 100))
    hours, remainder = divmod(total_cs, 360_000)
    minutes, remainder = divmod(remainder, 6_000)
    secs, centis = divmod(remainder, 100)
    return f"{hours}:{minutes:02d}:{secs:02d}.{centis:02d}"


def wrap_caption(text: str, width: int = 22) -> str:
    lines = textwrap.wrap(
        text,
        width=width,
        break_long_words=False,
        break_on_hyphens=False,
        max_lines=2,
        placeholder="…",
    )
    return "\n".join(lines)


def write_caption_srt(captions: list[Caption], path: Path) -> int:
    blocks = []
    for index, caption in enumerate(captions, start=1):
        blocks.append(
            f"{index}\n{_srt_time(caption.start)} --> {_srt_time(caption.end)}\n"
            f"{wrap_caption(caption.text, 34)}\n"
        )
    path.write_text("\n".join(blocks), encoding="utf-8-sig")
    return len(blocks)


def _escape_ass(text: str) -> str:
    return text.replace("\\", r"\\").replace("{", r"\{").replace("}", r"\}")


def _caption_with_highlight(caption: Caption, active_index: int) -> str:
    plain = [word.text for word in caption.words]
    split_at: int | None = None
    if len(join_words(plain)) > 22 and len(plain) > 1:
        candidates = []
        for index in range(1, len(plain)):
            left = len(join_words(plain[:index]))
            right = len(join_words(plain[index:]))
            overflow = max(0, left - 24) + max(0, right - 24)
            candidates.append((overflow, abs(left - right), index))
        split_at = min(candidates)[2]

    pieces: list[str] = []
    for index, word in enumerate(caption.words):
        if split_at is not None and index == split_at:
            pieces.append(r"\N")
        colour = "&H00A6F26D&" if index == active_index else "&H00FFFFFF&"
        token = r"{\c" + colour + "}" + _escape_ass(word.text)
        if pieces and pieces[-1] != r"\N":
            token = " " + token
        pieces.append(token)
    return "".join(pieces)


def write_highlight_ass(captions: list[Caption], path: Path) -> int:
    header = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
ScaledBorderAndShadow: yes
WrapStyle: 2

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Short,Segoe UI Semibold,72,&H00FFFFFF,&H00FFFFFF,&H00111111,&H80000000,-1,0,0,0,100,100,0,0,1,5,2,2,70,70,250,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    events: list[str] = []
    for caption in captions:
        for index, word in enumerate(caption.words):
            event_start = word.start
            event_end = (
                caption.words[index + 1].start
                if index + 1 < len(caption.words)
                else caption.end
            )
            event_end = max(event_start + 0.05, event_end)
            text = _caption_with_highlight(caption, index)
            events.append(
                f"Dialogue: 0,{_ass_time(event_start)},{_ass_time(event_end)},Short,,0,0,0,,{text}"
            )
    path.write_text(header + "\n".join(events) + "\n", encoding="utf-8-sig")
    return len(events)
