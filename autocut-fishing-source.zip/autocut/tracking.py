from __future__ import annotations

import gc
from pathlib import Path
from typing import Iterable


def smooth_positions(
    detections: Iterable[tuple[float, float | None]],
    *,
    alpha: float = 0.22,
    hold_seconds: float = 1.5,
    return_speed: float = 0.035,
) -> list[tuple[float, float]]:
    """Stabilize detections and gently return to centre after losing the subject."""
    result: list[tuple[float, float]] = []
    centre = 0.5
    last_seen = -1_000.0
    for timestamp, detected in detections:
        if detected is not None:
            detected = max(0.0, min(1.0, detected))
            centre += alpha * (detected - centre)
            last_seen = timestamp
        elif timestamp - last_seen > hold_seconds:
            delta = 0.5 - centre
            centre += max(-return_speed, min(return_speed, delta))
        result.append((timestamp, max(0.0, min(1.0, centre))))
    return result


def simplify_positions(
    positions: list[tuple[float, float]],
    *,
    minimum_interval: float = 0.45,
    movement_threshold: float = 0.008,
) -> list[tuple[float, float]]:
    if len(positions) <= 2:
        return positions
    kept = [positions[0]]
    for item in positions[1:-1]:
        elapsed = item[0] - kept[-1][0]
        moved = abs(item[1] - kept[-1][1])
        if elapsed >= minimum_interval and moved >= movement_threshold:
            kept.append(item)
    if positions[-1][0] > kept[-1][0]:
        kept.append(positions[-1])
    return kept


def detect_person_positions(video_path: Path, *, samples_per_second: float = 5.0) -> list[tuple[float, float]]:
    """Return smoothed horizontal centres for the most prominent person."""
    try:
        import cv2
        import mediapipe as mp
    except ImportError as exc:
        raise RuntimeError(
            "Componenta de urmărire automată nu este instalată. "
            "Rulează din nou setup_windows.bat."
        ) from exc

    capture = cv2.VideoCapture(str(video_path))
    if not capture.isOpened():
        raise RuntimeError("Filmarea intermediară nu a putut fi analizată pentru încadrare.")

    fps = float(capture.get(cv2.CAP_PROP_FPS) or 25.0)
    frame_count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    step = max(1, round(fps / max(1.0, samples_per_second)))
    detections: list[tuple[float, float | None]] = []

    pose_api = mp.solutions.pose
    landmark_ids = (
        pose_api.PoseLandmark.NOSE,
        pose_api.PoseLandmark.LEFT_SHOULDER,
        pose_api.PoseLandmark.RIGHT_SHOULDER,
        pose_api.PoseLandmark.LEFT_HIP,
        pose_api.PoseLandmark.RIGHT_HIP,
    )
    try:
        with pose_api.Pose(
            static_image_mode=False,
            model_complexity=0,
            smooth_landmarks=True,
            min_detection_confidence=0.4,
            min_tracking_confidence=0.4,
        ) as pose:
            frame_index = 0
            while True:
                ok, frame = capture.read()
                if not ok:
                    break
                if frame_index % step == 0:
                    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    result = pose.process(rgb)
                    centre: float | None = None
                    if result.pose_landmarks:
                        visible = [
                            result.pose_landmarks.landmark[index]
                            for index in landmark_ids
                            if result.pose_landmarks.landmark[index].visibility >= 0.35
                        ]
                        if visible:
                            weights = [max(0.1, point.visibility) for point in visible]
                            centre = sum(point.x * weight for point, weight in zip(visible, weights)) / sum(weights)
                    detections.append((frame_index / fps, centre))
                frame_index += 1
    finally:
        capture.release()
        # OpenCV's Windows backend can keep the media handle alive until the
        # Python wrapper is collected, even after release().  Force collection
        # before FFmpeg reopens or the temporary folder removes the file.
        del capture
        gc.collect()

    duration = frame_count / fps if frame_count else (detections[-1][0] if detections else 0.0)
    if not detections:
        return [(0.0, 0.5), (max(0.01, duration), 0.5)]
    if detections[-1][0] < duration:
        detections.append((duration, detections[-1][1]))
    return simplify_positions(smooth_positions(detections))
