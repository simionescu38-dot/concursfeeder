# AutoCut Fishing

Aplicație desktop pentru Windows care transformă filmări lungi în videoclipuri verticale pregătite pentru YouTube Shorts, TikTok și Reels.

## Versiunea 1.1

- elimină automat pauzele pe baza sunetului;
- detectează pescarul și îl urmărește automat în cadrul vertical 9:16;
- umple complet ecranul 9:16, fără margini sau fundal blurat;
- include urmărire automată și crop central fix;
- limitează rezultatul la 30, 45 sau 60 de secunde;
- caută automat momentele cu activitate audio și vizuală;
- generează 1, 2 sau 3 Shorts distincte din aceeași filmare;
- generează subtitrări românești sincronizate pe cuvinte, cu vocabular de pescuit;
- evidențiază cuvântul rostit și păstrează maximum două rânduri;
- oferă previzualizare 9:16 înainte de export;
- include presetări Universal, YouTube Shorts, TikTok și Facebook Reels;
- recuperează ultima procesare întreruptă și păstrează un jurnal de diagnostic;
- procesează totul local, fără încărcarea filmării pe internet;
- exportă MP4 H.264 la 1080×1920.
- evită oprirea exportului când Windows întârzie eliberarea unui fișier temporar.
- include motorul FFmpeg și modelul AI de subtitrare; după instalare funcționează offline.
- repetă automat transcrierea cu sensibilitate mărită dacă vocile sunt confundate cu zgomotul exterior.

## Instalare pentru utilizator

1. Deschide `AutoCut-Fishing-Setup.exe`.
2. Apasă **Instalează**.
3. Pornește aplicația din iconița **AutoCut Fishing** de pe Desktop.

Nu sunt necesare Python, FFmpeg, comenzi, fișiere `.bat` sau descărcări suplimentare.

## Crearea aplicației `.exe`

Rulează `build_windows.bat`. Pachetul va fi creat în:

`dist\AutoCut Fishing\AutoCut Fishing.exe`

Dacă Inno Setup este instalat, același script creează și kitul complet:

`installer\AutoCut-Fishing-Setup.exe`

Scriptul de build include automat FFmpeg, FFprobe și modelul `faster-whisper-small` în kitul Windows.

## Cum obții rezultate bune

- Pentru filmări orizontale în care pescarul se mișcă lateral, alege **Urmărire automată**.
- Pentru cadre apropiate, alege **Crop central**: imaginea umple complet ecranul.
- Începe cu pragul `-35 dB`, pauză minimă `0,8 sec` și protecție `0,18 sec`.
- Verifică întotdeauna clipul rezultat înainte de publicare.

## Limitări cunoscute

- Detectarea pauzelor se bazează pe sunet; vântul puternic poate păstra secțiuni care par inactive.
- Urmărirea v0.2 țintește persoana cea mai vizibilă; în mulțimi poate alege altă persoană.
- Transcrierea poate greși nume proprii și termeni de pescuit; fișierul `.srt` rămâne lângă export pentru corectare.

## Structură

- `app.py` – interfața aplicației;
- `autocut/core.py` – analiză și procesare video;
- `assets/` – iconița aplicației;
- `tests/` – teste automate;
- `build_windows.bat` – generare pachet Windows.
