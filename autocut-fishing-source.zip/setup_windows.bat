@echo off
setlocal
title AutoCut Fishing - Instalare
cd /d "%~dp0"

echo.
echo ========================================
echo       AutoCut Fishing - Instalare
echo ========================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo Python nu este instalat.
  echo Se deschide instalarea Python 3.12 prin winget...
  winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements
  if errorlevel 1 goto :install_error
)

where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo FFmpeg nu este instalat. Se instaleaza acum...
  winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
  if errorlevel 1 (
    echo.
    echo FFmpeg nu a putut fi instalat automat.
    echo Instaleaza-l manual si ruleaza din nou acest fisier.
    pause
    exit /b 1
  )
  echo.
  echo FFmpeg a fost instalat. Inchide aceasta fereastra,
  echo redeschide folderul si ruleaza din nou setup_windows.bat.
  pause
  exit /b 0
)

if not exist ".venv\Scripts\python.exe" (
  echo Se creeaza mediul aplicatiei...
  py -3.12 -m venv .venv
  if errorlevel 1 py -m venv .venv
)

echo Se instaleaza componentele necesare...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :install_error

echo.
echo Instalarea s-a terminat cu succes.
echo Se creeaza iconita pe Desktop...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1"
echo AutoCut Fishing porneste acum.
start "" ".venv\Scripts\pythonw.exe" app.py
exit /b 0

:install_error
echo.
echo Instalarea nu s-a putut finaliza.
echo Verifica internetul si incearca din nou.
pause
exit /b 1
