param(
    [switch]$SkipModelDownload
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectRoot

$python = Join-Path $projectRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $python)) {
    throw "Mediul Python de build lipsește."
}

$modelDir = Join-Path $projectRoot "models\faster-whisper-small"
$modelFile = Join-Path $modelDir "model.bin"
if (-not (Test-Path $modelFile)) {
    if ($SkipModelDownload) {
        throw "Modelul offline de subtitrare lipsește."
    }
    Write-Host "Se descarcă modelul AI pentru subtitrare offline..."
    & $python -c "from huggingface_hub import snapshot_download; snapshot_download('Systran/faster-whisper-small', local_dir=r'$modelDir')"
    if ($LASTEXITCODE -ne 0) { throw "Descărcarea modelului AI a eșuat." }
}

$ffmpeg = (Get-Command ffmpeg -ErrorAction Stop).Source
$ffprobe = (Get-Command ffprobe -ErrorAction Stop).Source

$pyInstallerArgs = @(
    "-m", "PyInstaller",
    "--noconfirm", "--clean", "--windowed",
    "--name", "AutoCut Fishing",
    "--icon", "assets\autocut_fishing.ico",
    "--add-data", "assets;assets",
    "--add-data", "apply_update.ps1;.",
    "--add-data", "models\faster-whisper-small;models\faster-whisper-small",
    "--add-binary", "$ffmpeg;.",
    "--add-binary", "$ffprobe;.",
    "--collect-all", "faster_whisper",
    "--collect-all", "ctranslate2",
    "--collect-all", "tokenizers",
    "--collect-all", "mediapipe",
    "--collect-all", "cv2",
    "--hidden-import", "autocut.tracking",
    "--hidden-import", "autocut.subtitles",
    "--hidden-import", "autocut.highlights",
    "app.py"
)

Write-Host "Se construiește aplicația Windows..."
& $python @pyInstallerArgs
if ($LASTEXITCODE -ne 0) { throw "Build-ul aplicației a eșuat." }

$appExe = Join-Path $projectRoot "dist\AutoCut Fishing\AutoCut Fishing.exe"
$process = Start-Process -FilePath $appExe -ArgumentList "--self-test" -Wait -PassThru
if ($process.ExitCode -ne 0) { throw "Autotestul pachetului Windows a eșuat." }

$isccCandidates = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)
$iscc = $isccCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { throw "Inno Setup 6 nu este instalat." }

& $iscc "AutoCutFishing.iss"
if ($LASTEXITCODE -ne 0) { throw "Crearea instalatorului a eșuat." }

$setup = Join-Path $projectRoot "installer\AutoCut-Fishing-Setup.exe"
$hash = (Get-FileHash -Algorithm SHA256 $setup).Hash
Write-Host "Instalator creat: $setup"
Write-Host "SHA256: $hash"
